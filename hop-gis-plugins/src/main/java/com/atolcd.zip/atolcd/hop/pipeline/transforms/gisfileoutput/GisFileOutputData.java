package com.atolcd.hop.pipeline.transforms.gisfileoutput;

/*
 * #%L
 * Apache Hop GIS Plugin
 * %%
 * Copyright (C) 2021 Atol CD
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Lesser Public License for more details.
 *
 * You should have received a copy of the GNU General Lesser Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/lgpl-3.0.html>.
 * #L%
 */

import java.io.OutputStreamWriter;
import org.apache.hop.core.row.IRowMeta;
import org.apache.hop.pipeline.transform.BaseTransformData;

public class GisFileOutputData extends BaseTransformData {

  public IRowMeta outputRowMeta;

  public OutputStreamWriter writer;

  /**
   * Einmalig (aus der ersten Zeile) ermittelter Ausgabedateiname, wenn fileNameInField aktiv ist
   * (siehe GisFileOutputMeta). Bleibt null, wenn die Option nicht genutzt wird - dann wird
   * weiterhin der statische outputFileName aus der Meta verwendet.
   */
  public String resolvedFileName;

  public GisFileOutputData() {
    super();
  }
}
